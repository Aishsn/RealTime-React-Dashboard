import React from 'react';
import { Grid, Card, CardContent, Typography } from '@mui/material';
import { useRealtime } from './RealtimeProvider';

export default function SummaryCards(){
  const { state } = useRealtime();
  if(!state) return <Card><CardContent><Typography>Connecting to real-time server...</Typography></CardContent></Card>;

  const d = state;
  return (
    <Grid container spacing={2}>
      {console.log('summary info d',d)}
      <Grid item xs={12} sm={6} md={3}><Card><CardContent>
        <Typography variant="subtitle2">Total Active Users</Typography>
        <Typography variant="h5">{d.users.totalActive}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={6} md={3}><Card><CardContent>
        <Typography variant="subtitle2">Active Users by Platform</Typography>
        <Typography>Web: {d.users.platforms.web}</Typography>
        <Typography>Mobile: {d.users.platforms.mobile}</Typography>
        <Typography>Tablet: {d.users.platforms.tablet}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={6} md={2}><Card><CardContent>
        <Typography variant="subtitle2">API Rejections (Last 5m)</Typography>
        <Typography variant="h6">{d.apiRejectionsLast5Min}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={6} md={2}><Card><CardContent>
        <Typography variant="subtitle2">New Projects (Last 7d)</Typography>
        <Typography variant="h6">{d.newProjectsLast7Days}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={6} md={2}><Card><CardContent>
        <Typography variant="subtitle2">Live Projects</Typography>
        <Typography variant="h6">{d.totalLiveProjects}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={6} md={4}><Card><CardContent>
        <Typography variant="subtitle2">Sensors (Active / Inactive)</Typography>
        <Typography>Active: {d.sensorTypeObj.activeCampaigns}</Typography>
        <Typography>Inactive: {d.sensorTypeObj.inactiveCampaigns}</Typography>
      </CardContent></Card></Grid>

      <Grid item xs={12} sm={12} md={8}><Card><CardContent>
        <Typography variant="subtitle2">Sensor Types Distribution</Typography>
        <Typography variant="body2">{Object.entries(d.sensorTypeObj.types).map(([k,v])=>`${k}: ${v}`).join(' • ')}</Typography>
      </CardContent></Card></Grid>
    </Grid>
  )
}